import java.util.*;

public class Test
{
   public static void main(String[] args)
   {
      Animal rex = new Animal(4);
      Animal bob = new Professor(0, true, "Bob", 0, 2);
      Professor julie = new Professor(0, true, "Julie", 0, 2);
      Person jane = new Student(3.26, 0, "Jane", 0, 2);
      
           
      System.out.println(rex.greet(bob));    // Sniff
      System.out.println(bob.greet(rex));    // Grrr
      System.out.println(julie.greet(bob));  // Grrr
      System.out.println(jane.greet(julie)); // Hey
      System.out.println(julie.greet(jane)); // Hello
   
/*      ArrayList<Professor> profs = new ArrayList<>();
      profs.add(new Professor(500000, false, "Julie", 0, 2));
      profs.add(new Professor(300000, false, "Paul", 0, 2));
      profs.add(new Professor(250001, true, "Phil", 0, 2));
      profs.add(new Professor(250000, true, "Hugh", 0, 2));
      profs.add(new Professor(200000, false, "Kurt", 0, 2));
   
      // Below - Several of many different ways of accomplishing the sort
      // 1. ------------------------------------------------------------------------------------------
       Comparator<Professor> comp1 = (p1, p2) -> { if (p1.hasTenure() && !p2.hasTenure()) return -1;
                                                    if (!p1.hasTenure() && p2.hasTenure()) return 1;
                                                    return 0;
                                                };
      Comparator<Professor> comp2 = (p1, p2) -> p2.getName().compareTo(p1.getName());
      Comparator<Professor> compFinal = comp1.thenComparing(comp2);
      
      // 2. ---------------If you cheated and used natural boolean ordering!--------------------------
      Comparator<Professor> comp1 = Comparator.comparing(Professor::hasTenure).reversed(); 
      Comparator<Professor> comp2 = Comparator.comparing(Professor::getName).reversed();
      Comparator<Professor> compFinal = comp1.thenComparing(comp2);
       
      // 3. ------------------------------------------------------------------------------------------
      Comparator<Professor> compFinal = (p1, p2) -> { if (p1.hasTenure() && !p2.hasTenure()) return -1;
                                                      if (!p1.hasTenure() && p2.hasTenure()) return 1;
                                                      return p2.getName().compareTo(p1.getName());
                                                    };
      
      Collections.sort(profs, compFinal);

      for (Professor p : profs)
      {
         System.out.println(p.getName());
      }
      
      // Below - Several of many different ways to compute average mortgage of tenured profs.
      // 1. ------------------------------------------------------------------------------------------
       double avg = profs.stream().filter(Professor::hasTenure)
                                 .mapToDouble(Professor::getMortgage)
                                 .average()
                                 .getAsDouble();
       
      // 2. ------------------------------------------------------------------------------------------
      double avg = profs.stream().filter(p -> p.hasTenure())
                                 .mapToInt(p -> p.getMortgage())
                                 .sum()/(double)profs.stream().filter(Professor::hasTenure).count();
      System.out.println(avg);
  */    
   }
}
