public class Animal
{
   private int numLegs;
   
   public Animal(int legs) {numLegs = legs;}
   
   public String toString()
   {
      return "I am an Animal object with " + numLegs + " legs";
   }
   
   public String greet(Animal a)
   {
      return "Sniff";
   }

   public boolean equals(Object o)
   {
      if (o == null)
         return false;
      
      if (getClass() != o.getClass())
         return false;
      
      return numLegs == ((Animal)o).numLegs;
   }
}
